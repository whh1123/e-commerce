# from rest_framework import serializers
# from .models import Category, Item
#
# class ItemSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Item # get item information
#         fields = (
#             "id",
#             "name",
#             "get_absolute_url",
#             "description",
#             "price",
#
#         )

# a try for realizing the sorting function